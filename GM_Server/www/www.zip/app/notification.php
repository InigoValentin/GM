<?php
	$con = mysqli_connect("mysql1.000webhost.com","a1171284_gm","gmargolari12","a1171284_gm");
	$res = mysqli_query($con, "SELECT * FROM `notification` WHERE time + INTERVAL duration MINUTE >= now();"); //TODO: Where clause
    while($row = mysqli_fetch_array($res)){
		echo "<notification>";
		echo "<id>$row[id]</id>";
		echo "<type>$row[type]</type>";
		echo "<title>$row[title]</title>";
		echo "<text>$row[text]</text>";
		echo "<gm>$row[gm]</gm>";
		echo "</notification>\n";
	}
	
?>
 
