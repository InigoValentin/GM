<?php
	$con = mysqli_connect("mysql1.000webhost.com","a1171284_gm","gmargolari12","a1171284_gm");
	$name = mysqli_real_escape_string($con, $_GET['name']);
	$phone = mysqli_real_escape_string($con, $_GET['phone']);
	$code = mysqli_real_escape_string($con, $_GET['code']);
	$query = "INSERT INTO admin (name, code, phone, enabled) VALUES('$name', '$code', '$phone', 0)";
	echo $query;
	
?>
