<!DOCTYPE html>
<html>
	<head>
		<meta content="text/html; charset=windows-1252" http-equiv="content-type"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">
		<title>Lugares</title>
	</head>
	<body>
		<?php
			$con = mysqli_connect("mysql1.000webhost.com","a1171284_gm","gmargolari12","a1171284_gm");
			$error = 0;
			$inserted = 0;
			for ($i = 0; $i < 10; $i ++){
				$name = $_GET['name_' . $i];
				$address = $_GET['address_' . $i];
				$cp = $_GET['cp_' . $i];
				$lat = $_GET['lat_' . $i];
				$lon = $_GET['lon_' . $i];
				$query = "INSERT INTO place (name, address, cp, lat, lon) VALUES ('$name', '$address', '$cp', $lat, $lon);";
				if (strlen($name) > 0 && $address != "" && $cp != "" && $lat != "" && $lon != ""){
					mysqli_query($con, $query);
					echo "Entrada anadida: $name<br/>\n";
					$inserted ++;
				}
				else if (strlen($name) > 0 && ($address == "" || $cp == "" || $lat == "" || $lon == "")){
					echo "Error anadiendo: $name (Direccion: $address, CP: $cp, GPS: $lat, $lon)<br/>\n;";
					$error ++;
				}
			}
			echo "<br/><br/><br/>$inserted nuevas entradas anadidas.<br/>\n$error errores.\n<br/><br/><form action='/add/place.php'><input type='submit' value='Continuar anadiendo'/></form>";
		?>
	</body>
</html>